## Scotch React Todo
A demo that backs a Scotch article on building a Todo App using React.
